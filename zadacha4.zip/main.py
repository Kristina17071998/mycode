# Считываем количество покупок
import sys

n = int(sys.stdin.buffer.raw.readline().decode('utf-8').strip())

# Считываем сами покупки и создаем список
покупки = [sys.stdin.buffer.raw.readline().decode('utf-8').strip() for _ in range(n)]

# Выводим список покупок
print ('\n')
print(*покупки, sep='\n')

