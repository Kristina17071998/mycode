def check_temperature (temperature):
if temperature < 15.5:
return "ХОЛОДНО"
elif temperature > 28:
return "ЖАРКО"
else:
return "НОРМАЛЬНО"

# Считываем температуру с клавиатуры, но теперь не выдает ошибку при введении запятой вместо точки
temp_in_cel = float(input("Введите температуру в градусах Цельсия: ").replace(',', '.'))

# Проверяем температуру и выводим результат
result = check_temperature (temp_in_cel)
print(result)
