def check_letters(short, long):
  return all(letter in long for letter in short)

words = []
while True:
  word = input()
  if word.lower() == 'стоп':
      break
  words.append(word)

if len(words) < 2:
  print("Введите как минимум два разных по длине слова.")
else:
  shortest_word = min(words, key=len)
  longest_word = max(words, key=len)

  result = "ДА" if check_letters(shortest_word, longest_word) else "НЕТ"
  print(result)