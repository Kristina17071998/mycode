def naiti_kota(stroki):
  return any('Кот' in stroka or 'кот' in stroka for stroka in stroki)

# Считываем количество строк
while True:
  try:
    n = int(input("Введите количество строк: "))
    break
  except ValueError:
    print("Некорректный ввод. Введите целое число.")

# Считываем строки
stroki = [input() for _ in range(n)]

# Проверяем наличие кота и выводим результат
if naiti_kota(stroki):
  print("МЯУ")
else:
  print("НЕТ")
