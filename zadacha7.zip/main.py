from solution import LittleBell
bell = LittleBell()
bell.sound()
bell.sound()