class LittleBell:
  def sound(self):
      print("ding")
