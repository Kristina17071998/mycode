# Считываем строку
line = input("Введите строку: ")

# Создаем новую строку, повторяя каждый символ дважды
new_line= ''.join([symbol * 2 for symbol in line])

# Выводим новую строку
print(new_line)
